package base_classes;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home_page {
	WebDriver dr;
	Logger log;
	public home_page(WebDriver dr, Logger log)
	{
		this.dr=dr;
		this.log=log;
	}
	public void create_log(String meth_name, String exp_res, String act_res, String test_res)
	{
		if(test_res.compareTo("PASS")==0)
		{
			if(exp_res=="")
				log.info("Method "+ meth_name+" invoked \n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n");
			else
				log.info("Method "+ meth_name+" invoked \n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n Expected Result: "+exp_res+"\n Actual Result: "+act_res+"\n Test Result: "+test_res+"\n");
	
		}
		else {
			if(exp_res=="")
				log.info("Method "+ meth_name+" invoked \n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n");
			else
				log.info("Method "+ meth_name+"\n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n Expected Result: "+exp_res+"\n Actual Result: "+act_res+"\n Test Result: "+test_res+"\n");
		}
	}
	public String verify_src_prod()
	{
		String actual_text;
		actual_text=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")).getText();
		return actual_text;
	}
	public String verify_categories()
	{
		String actual_text;
		actual_text=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/table[1]/tbody/tr/th")).getText();
		return actual_text;
	}
	public int search_category(String category)
	{
		int flag=0;
		for(int i=1;i<=3;i++)
		{
			if(dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/table[2]/tbody/tr["+i+"]/td/a")).getText().compareTo(category)==0)
			{
				dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td[1]/table[2]/tbody/tr["+i+"]/td/a")).click();
				flag=1;
				break;
			}
		}
		return flag;
	}
}
