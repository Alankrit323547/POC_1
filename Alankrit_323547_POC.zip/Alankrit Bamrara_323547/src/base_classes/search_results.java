package base_classes;


import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class search_results {
	WebDriver dr;
	Logger log;
	public search_results(WebDriver dr, Logger log)
	{
		this.dr=dr;
		this.log = log;
	}
	public void create_log(String meth_name, String exp_res, String act_res, String test_res)
	{
		if(test_res.compareTo("PASS")==0)
		{
			if(exp_res=="")
				log.info("Method "+ meth_name+" invoked \n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n");
			else
				log.info("Method "+ meth_name+" invoked \n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n Expected Result: "+exp_res+"\n Actual Result: "+act_res+"\n Test Result: "+test_res+"\n");
	
		}
		else {
			if(exp_res=="")
				log.info("Method "+ meth_name+" invoked \n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n");
			else
				log.info("Method "+ meth_name+"\n"+"TC_TD: testng.test_bookstore#"+meth_name+"\n Expected Result: "+exp_res+"\n Actual Result: "+act_res+"\n Test Result: "+test_res+"\n");
		}
	}
	public String verify_number()
	{
		 String actual_txt = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td")).getText();
		 int index = actual_txt.indexOf(":");
		 int num = index+2;
		 String no_of_prod = actual_txt.substring(num, actual_txt.indexOf('p')-1);
		 return no_of_prod;
	}
	public String return_book_name(int i)
	{
		String book_name, row_txt;
		int c=i*2+1;
		row_txt = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr["+c+"]/td[2]")).getText();
		book_name = row_txt.substring(0, row_txt.indexOf(":")-6);
			//book_price = row_txt.substring(row_txt.indexOf("$")+1, row_txt.length());
		return book_name;
	}
	public String return_book_price(int i)
	{
		String book_price, row_txt;
		int c=i*2+1;
		row_txt = dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr["+c+"]/td[2]")).getText();
		//book_name = row_txt.substring(0, row_txt.indexOf(":")-6);
		book_price = row_txt.substring(row_txt.indexOf("$")+1, row_txt.length());
		return book_price;
	}
}
