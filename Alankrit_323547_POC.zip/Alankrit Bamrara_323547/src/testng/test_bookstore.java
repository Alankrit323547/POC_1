package testng;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base_classes.home_page;
import base_classes.search_results;

import org.testng.annotations.DataProvider;

public class test_bookstore {
	int i=-1,j=-1;
	WebDriver dr;
	home_page homepage;
	search_results searchresults;
	Logger log=Logger.getLogger("devpinoyLogger");;
	@BeforeClass
	public void launch_browser()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
		 dr = new ChromeDriver();
		 dr.get("http://examples.codecharge.com/Store/Default.php");
	}
  @Test(priority=0)
  public void verify_txt() {
	  homepage = new home_page(dr,log);
	  WebDriverWait wt = new WebDriverWait(dr,10);                             
	  wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/table[5]/tbody/tr/td[1]/table[2]/tbody/tr[2]/td/a")));
	  String act_txt,exp_txt="Search Products";
	  act_txt = homepage.verify_src_prod();
	  if(act_txt.compareTo(exp_txt)!=0)
			homepage.create_log("verify_txt",exp_txt , act_txt, "FAIL");
	  Assert.assertEquals(act_txt, exp_txt);
	 homepage.create_log("verify", exp_txt, act_txt, "PASS");
	  }
  @Test(priority=1)
  public void verify_txt_1() {
	  homepage = new home_page(dr,log);
	  String act_txt,exp_txt="Categories";
	  act_txt = homepage.verify_categories();
	  if(act_txt.compareTo(exp_txt)!=0)
			homepage.create_log("verify_txt",exp_txt , act_txt, "FAIL");
	  Assert.assertEquals(act_txt, exp_txt);
	  homepage.create_log("verify", exp_txt, act_txt, "PASS");
	  }
  @Test (priority=2)
  public void search()
  {
	  homepage = new home_page(dr,log);
	  int flag = homepage.search_category("HTML & Web design");
	  if(flag==0)
			homepage.create_log("search","" , "", "FAIL");
	  Assert.assertEquals(1, flag);
	  homepage.create_log("search","","","PASS");
  }
  @Test(priority=3)
  public void verify_number()
  {
	  searchresults = new search_results(dr,log);
	  WebDriverWait wt = new WebDriverWait(dr,10);                              
	  wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/table[5]/tbody/tr/td/table[1]/tbody/tr/td/form/table[2]/tbody/tr[3]/td/input")));
	  String exp_no = "4", act_no=searchresults.verify_number();
	  if(exp_no.compareTo(act_no)!=0)
		  searchresults.create_log("verify_number", exp_no, act_no, "FAIL");
	  Assert.assertEquals(exp_no, act_no);
	  searchresults.create_log("verify_number", exp_no, act_no, "PASS");
  }
  @Test (priority=4, dataProvider="expected_book_names")
  public void verify_book_name(String exp_name)
  {
	  i++;
	  searchresults = new search_results(dr,log);

	  WebDriverWait wt = new WebDriverWait(dr,10);                              
	  wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/table[5]/tbody/tr/td/table[1]/tbody/tr/td/form/table[2]/tbody/tr[3]/td/input")));
	  String act_book_name = searchresults.return_book_name(i);
	  if(act_book_name.compareTo(exp_name)!=0)
		  searchresults.create_log("verify_book_name", exp_name, act_book_name, "FAIL");
	  Assert.assertEquals(act_book_name, exp_name);
	  searchresults.create_log("verify_book_name", exp_name, act_book_name, "PASS");
  }
  @Test (priority=5, dataProvider="expected_book_prices")
  public void verify_book_price(String exp_price)
  {
	  j++;
	  searchresults = new search_results(dr,log);

	  WebDriverWait wt = new WebDriverWait(dr,10);                              
	  wt.until(ExpectedConditions.elementToBeClickable(By.xpath("/html/body/table[5]/tbody/tr/td/table[1]/tbody/tr/td/form/table[2]/tbody/tr[3]/td/input")));
	  String act_book_price = searchresults.return_book_price(j);
	  if(act_book_price.compareTo(exp_price)!=0)
		  searchresults.create_log("verify_book_price", exp_price, act_book_price, "FAIL");
	  Assert.assertEquals(act_book_price, exp_price);
	  searchresults.create_log("verify_book_price", exp_price, act_book_price, "PASS");
  }
  @DataProvider (name="expected_book_names")
  public String[] exp_book_names()
  {
	  String[] exp_txt = {"Flash 4 Magic", "Web Design in a Nutshell", "HTML 4", "1001 Web Site Tips and Tricks"};
	  return exp_txt;
  }
  @DataProvider (name="expected_book_prices")
  public String[] exp_book_prices()
  {
	  String[] exp_txt = {"36.00", "23.96", "15.99", "39.95"};
	  return exp_txt;
  }
}
